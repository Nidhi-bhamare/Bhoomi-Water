from cv2 import log
from django.shortcuts import render,HttpResponse,redirect
from datetime import datetime as d
from BhoomiAqua.models import Contact
from BhoomiAqua.models import Product
from BhoomiAqua.models import Users
from BhoomiAqua.models import Cart
from django.contrib import messages
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth import login as log_in
from django.contrib.auth import logout as log_out
from django.contrib.auth.models import User

# Create your views here.

def cart(request):
    lst=list(Cart.objects.filter(username=request.user.username))
    data=[]
    sum=0
    for i in lst:
        d={}
        d['product_id']=i.product_id
        d['quantity']=i.quantity
        d['username']=i.username
        x=Product.objects.filter(product_id=i.product_id)
        d['price']=x[0].price
        d['name']=x[0].name
        d['total']=d['price']*d['quantity']
        sum+=d['total']
        data.append(d)
    
    context={
        "data":data,
        'sum':sum
    }
    return render(request,"cart.html",context)



def addToCart(request):
    c=Cart(username=request.user.username,quantity=request.POST.get('quantity'), product_id=request.POST.get('prodId'))
    c.save()
    return redirect("/index")

def login(request):
    if(not request.user.is_anonymous):
        print("in anonymous")
        return redirect("/")
    if(request.method=='POST'):
        username=request.POST.get('username')
        password=request.POST.get('password')
        print(username,password)
        user=authenticate(request, username=username,password=password)
        if user is not None:
            log_in(request,user)
            print("logged in")
            return redirect("/index")
    print("not logged in")
    return render(request,"login.html")

def logout(request):
    log_out(request)
    return redirect("/login")

def index(request):
    print("in index")
    print(request.user.is_anonymous)
    if(request.user.is_anonymous):
        print("in anonymous")
        return redirect("/login")
    list_prdct=Product.objects.all()
    context={
        'data':list(list_prdct)
    }
    with open("static/crousel_msgs.txt") as file:
        list_all=[line.rstrip() for line in file]
    for i in range(1,len(list_all)+1):
        context[f'crousel_{i}']=list_all[i-1]
    return render(request,"index.html",context)


def about(request):
    if(request.user.is_anonymous):
        print("in anonymous")
        return redirect("/login")
    return render(request,'about.html')


def contacts(request):
    if(request.user.is_anonymous):
        print("in anonymous")
        return redirect("/login")
    if(request.method=="POST"):
        name=request.POST.get('name')
        email=request.POST.get('email')
        suggestion=request.POST.get('suggestion')
        query=request.POST.get('query')
        category=request.POST.get('category')
        mobile_no=request.POST.get('mobile_no')
        city=request.POST.get('city')
        date=d.today()

        obj=Contact(name=name, email=email, mobile=mobile_no, suggestion=suggestion, query=query, category=category, city=city, time=date)
        try:
            obj.save()
            messages.success(request, 'Profile details updated.')
        except:
            messages.warning(request, 'Something went wrong')

    return render(request,"contact_us.html")

def signup(request):
    if(request.method=='POST'):
        username=request.POST.get('username')
        password=request.POST.get('password')
        email=request.POST.get('email')
        contact=request.POST.get('contact')
        print(username,password)
        obj=Users(name=username,email=email,contact=contact,password=password)
        obj.save()
        user=User.objects.create_user(username=username,password=password,email=email)
        user.save()
        return render(request,"login.html")
    return render(request,"signup.html")