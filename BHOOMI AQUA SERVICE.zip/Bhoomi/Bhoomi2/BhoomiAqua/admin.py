from django.contrib import admin
from .models import Product
from .models import Contact
from .models import Users
from .models import Cart

# Register your models here.
admin.site.register(Product)
admin.site.register(Contact)
admin.site.register(Users)
admin.site.register(Cart)