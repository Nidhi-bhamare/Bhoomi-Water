from django.db import models
from datetime import datetime
# Create your models here.
class Contact(models.Model):
    name=models.CharField(max_length=100)
    email=models.EmailField()
    suggestion=models.TextField()
    query=models.TextField()
    city=models.CharField(max_length=35)
    category=models.CharField(max_length=35)
    mobile=models.IntegerField()
    time=models.DateField()

class Cart(models.Model):
    product_id=models.IntegerField()
    quantity=models.IntegerField()
    username=models.CharField(max_length=100)

class Product(models.Model):
    product_id=models.IntegerField()
    price=models.FloatField()
    name=models.CharField(max_length=100)

class Users(models.Model):
    name=models.CharField(max_length=100)
    contact=models.CharField(max_length=100)
    email=models.EmailField()
    password=models.CharField(max_length=100)

    def __str__(self) -> str:
        return self.name+', '+self.email