from django.contrib import admin
from django.urls import path
from BhoomiAqua import views

urlpatterns = [
    path('', views.index,name='home'),
    path('about',views.about,name='about'),
    path('contacts',views.contacts,name='contacts'),
    path('index',views.index,name='index'),
    path('login', views.login,name='login'),
    path('signup', views.signup,name='signup'),
    path('logout',views.logout, name='logout'),
    path('addToCart',views.addToCart, name='addToCart'),
    path('cart', views.cart,name='cart'),
]